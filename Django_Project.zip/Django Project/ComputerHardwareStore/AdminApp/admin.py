from django.contrib import admin
from .models import Category,Product,Accounts,OrderMaster

# Register your models here.
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['id','cat_name']

class ProductAdmin(admin.ModelAdmin):
    list_display = ['id','product_name','price','description','image','qty']

class AccountsAdmin(admin.ModelAdmin):
    list_display = ['cardno','cvv','expiry','balance']

class OrderMasterAdmin(admin.ModelAdmin):
    list_display = ['user','date_of_purchase','amount','details']

admin.site.register(Product,ProductAdmin)
admin.site.register(Category,CategoryAdmin)
admin.site.register(Accounts,AccountsAdmin)
admin.site.register(OrderMaster,OrderMasterAdmin)


