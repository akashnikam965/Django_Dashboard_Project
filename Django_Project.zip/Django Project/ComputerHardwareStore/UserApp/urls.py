
from django.urls import path
from . import views

urlpatterns = [
    path('',views.Homepage),
    path('ShowProducts/<id>',views.ShowProducts),
    path('ViewDetails/<id>',views.ViewDetails),
    path('Login',views.Login),
    path('SignUp',views.SignUp),
    path('LogOut',views.LogOut),
    path('AddToCart',views.AddToCart),
    path('ShowCart',views.ShowCart),
    path('ModifyCart',views.ModifyCart),
    path('MakePayment',views.MakePayment),
    path("ContactUs",views.ContactUs),
    path("AboutUs",views.AboutUs),
    path("SearchRecord",views.SearchRecord),

]
