from django.shortcuts import render,redirect
from django.http import HttpResponse
from AdminApp.models import Product,Category,Accounts,OrderMaster
from UserApp.models import UserInfo,MyCart,ContactInfo

# Create your views here.
def Homepage(request):
    cats = Category.objects.all()
    products = Product.objects.all()
    return render(request,"homepage.html",{"cats":cats,"products":products})

def ShowProducts(request,id):
    cat = Category.objects.get(id=id)
    products = Product.objects.filter(cat_fk = id)
    cats = Category.objects.all()
    return render(request,"homepage.html",{"products":products,"cats":cats,"cat":cat})

def ViewDetails(request,id):
    product = Product.objects.get(id=id)
    cats = Category.objects.all()
    item = product
    if(item.qty == 0):
        msg="Item is OutofStock"
        return render(request,"ViewDetails.html",{"product":product,"cats":cats,"msg":msg})
    return render(request,"ViewDetails.html",{"product":product,"cats":cats})

def AddToCart(request):
    if(request.method == "POST"):
        if("uname" in request.session):
            pid = request.POST["pid"]
            qty = request.POST["qty"]
            uname = request.session["uname"]
            item = MyCart()
            item.user = UserInfo.objects.get(username = uname)
            item.product = Product.objects.get(id=pid)
            try:
                items = MyCart.objects.get(product_id=pid)
            except:
                item.qty = qty
                item.save()
                return redirect(ShowCart)
            else:
                return redirect(Homepage)
        else:
            return redirect(Login)
            
def ShowCart(request):
    items = MyCart.objects.filter(user = request.session["uname"])
    
    total = 0
    for item in items:
        total += item.qty * item.product.price
    request.session["total"] = total

    cats = Category.objects.all()
    return render(request,"ShowCart.html",{"items":items,"cats":cats})

def ModifyCart(request):
    action = request.POST["action"]
    pid = request.POST["pid"]    
    item = MyCart.objects.get(user = request.session["uname"],product = pid)

    if(action == "Remove"):
        item.delete()
    else:
        item.qty = request.POST["qty"]
        item.save()
    return redirect(ShowCart)

def MakePayment(request):
    if(request.method == "GET"):
        return render(request,"MakePayment.html",{})
    else:
        cardno = request.POST["cardno"]
        cvv = request.POST["cvv"]
        expiry = request.POST["expiry"]
        try:
            buyer = Accounts.objects.get(cardno=cardno,cvv=cvv,expiry=expiry)
        except:
            return redirect(MakePayment)
        else:
            owner = Accounts.objects.get(cardno="8877665544332211",cvv="321",expiry="12/2030")
            amount = request.session["total"]
            buyer.balance -= amount
            owner.balance += amount
            buyer.save()
            owner.save()
            items = MyCart.objects.filter(user = request.session["uname"])
            order = OrderMaster()
            order.user = UserInfo.objects.get(username=request.session["uname"])
            order.amount = request.session["total"]
            details = []
            for item in items:
                details.append(item.product.product_name)
                p1 = Product.objects.get(id=item.product.id)
                print(p1.qty,item.product.qty)
                p1.qty -= item.qty
                p1.save()
                item.delete()

            order.details =",".join(details)
            order.save()
            # return redirect(Homepage)
            return render(request,"invoice.html",{"order":order})

def Login(request):
    if(request.method == "GET"):
        return render(request,"Login.html",{})
    else:
        uname = request.POST["uname"]
        psw = request.POST["psw"]
        try:
            user = UserInfo.objects.get(username=uname,password=psw)
        except:
            return redirect(Login)
        else:
            request.session["uname"]=uname
            return redirect(Homepage)

def SignUp(request):
    if(request.method == "GET"):
        return render(request,"SignUp.html",{})
    else:
        uname = request.POST["uname"]
        psw = request.POST["psw"]
        email = request.POST["email"]
        try:
            user = UserInfo.objects.get(username=uname,email=email)
        except:
            user=UserInfo(uname,psw,email)
            user.save()
            return redirect(Homepage)
        else:
            return redirect(SignUp)
    
def LogOut(request):
    request.session.clear()
    return redirect(Homepage)

def ContactUs(request):
    if(request.method == "GET"):
        return render(request,"ContactUs.html",{})
    else:
        fname = request.POST["fname"]
        lname = request.POST["lname"]
        country = request.POST["country"]
        subject = request.POST["subject"]
        con = ContactInfo()
        con.fname = fname
        con.lname = lname
        con.country = country
        con.subject = subject
        con.save()
        return redirect(Homepage)
    
def AboutUs(request):
    return render(request,"AboutUs.html",{})

def SearchRecord(request):
    pname = request.POST["pname"]
    prods = Product.objects.filter(product_name = pname)
    return render(request,"homepage.html",{"prods":prods})